require('babel-register')
require('./server')
