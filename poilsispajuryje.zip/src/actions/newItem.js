import axios from 'axios';
import { startRequest, responseSuccess, responseFailure } from './global';
import { receiveItem } from './items';

export const ADD_ITEM = 'ADD_ITEM';
export const CLEAR_FIELDS = 'CLEAR_FIELDS';
export const RECEIVE_NEW_ITEM = 'RECEIVE_ITEM';

export const addItem = (payload) => {
  return {
    type: ADD_ITEM,
    payload
  }
}

export const clearFields = () => {
  return {
    type: CLEAR_FIELDS
  }
}

export const postItem = (payload) => {
  return (dispatch, store) => {
    
    dispatch(startRequest());
    
    axios.post('http://localhost:3000/api/items', store.getState().newItem)
      .then(item => {
        dispatch(receiveItem(item))
        dispatch(responseSuccess());
      })
      .catch(err => {
        console.error(err);
        dispatch(responseFailure(err));
      })

  }
}