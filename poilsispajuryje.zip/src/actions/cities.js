import { startRequest, responseSuccess, responseFailure } from './global';
export const SELECT_CITY = 'SELECT_CITY';
export const RECEIVE_CITIES = 'RECEIVE_CITIES';
export const SET_LOADED_ITEMS_FLAG = 'SET_LOADED_ITEMS_FLAG';

export const selectCity = (id) => {
    return {
        type: SELECT_CITY,
        cityId: id
    }
}

export const receiveCities = (payload) => {
    return {
        type: RECEIVE_CITIES,
        payload
    }
}


export const setLoadedItemsFlagInSelectedCity = (cityId) => {
    return {
        type: SET_LOADED_ITEMS_FLAG,
        cityId
    }
}

export const fetchCities = () => {

  return (dispatch) => {

    dispatch(startRequest());
    return fetch(`http://localhost:3000/api/cities`)
        .then(cities => cities.json())
        .then(cities => {
            dispatch(receiveCities(cities));
            dispatch(responseSuccess());
        })
        .catch(err => {
            console.error(err);
            dispatch(responseFailure(err));
        }) 
  }
}