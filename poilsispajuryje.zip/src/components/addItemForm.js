import React from 'react';
import {initialNewItemState} from '../reducers/newItem';

export default class AddItemForm extends React.Component {

	constructor(props) {
		super(props);

		this.state = this.props.initialState;
		this.handleSubmit = this.handleSubmit.bind(this);
		this.handleInputChange = this.handleInputChange.bind(this);
		this.handleCheckboxToggle = this.handleCheckboxToggle.bind(this);
		this.handleOnBlur = this.handleOnBlur.bind(this);
	}

	componentWillReceiveProps(nextProps) {
		this.setState(nextProps.initialState);
	}
	
	handleSubmit(e) {
		e.preventDefault();
		this.props.onItemSubmit(this.state);
	}

	handleInputChange(e) {
		const target = e.target;
		const value = target.value;
		const name = target.name;
		this.setState({[name]: value });
	}

	handleCheckboxToggle(e) {
		const target = e.target;
		let types = this.state.types;

		if (target.checked) {
			types.push(target.value)
		} else {
			types.splice(types.indexOf(target.value), 1);
		}
		this.setState({types: types});
	}

	isCheckboxChecked(name, id) {
		return this.state[name].indexOf(id) > -1;
	}

	handleOnBlur() {
		this.props.onInputChange(this.state);
	}

	render() {
		return (
			<form onSubmit={this.handleSubmit}>
				<input
					type="text"
					name="title"
					placeholder="Pavadinimas"
					value={this.state.title}
					onChange={this.handleInputChange}
					onBlur={this.handleOnBlur}
				/><br />
				<select
					value={this.state.city}
					name="city"
					onChange={this.handleInputChange}
				>
					{Object.keys(this.props.citiesMap).map(cityId => {
						return (
							<option key={cityId} value={cityId}>
									{this.props.citiesMap[cityId].name}
							</option>
						)
					})}
				</select><br />
				<div>
				
					{Object.keys(this.props.typesMap).map(typeId => {
						const name = this.props.typesMap[typeId].name;
						return (
							<div key={typeId}>
								<input 
									onChange={this.handleCheckboxToggle}
									checked={this.isCheckboxChecked('types', typeId)}
									type="checkbox"
									name="types"
									value={typeId}
								/> 
								{name}
							</div>
						)
				})}
				</div>
				<input
					type="text"
					name="address"
					placeholder="Adresas"
					value={this.state.address}
					onChange={this.handleInputChange}
				/>
        <input type="submit" value="Submit" />
			</form>
		)
	}
}