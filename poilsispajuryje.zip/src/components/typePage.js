import React from 'react';

export default class TypePage extends React.Component {
    render() {
        return (
            <div>This is Type page</div>
        )
    }
}