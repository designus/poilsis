import React from 'react';

export default class IndexPage extends React.Component {
    render() {
        return (
            <div>           
                <div>This is index page</div>
            </div>
        )
    }
}