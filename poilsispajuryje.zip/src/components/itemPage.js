import React from 'react';

export default class ItemPage extends React.Component {
    render() {
        return (
            <div>This is Item page</div>
        )
    }
}