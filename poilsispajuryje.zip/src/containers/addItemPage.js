import React from 'react';
import {connect} from 'react-redux';
import AddItemForm from '../components/addItemForm';
import {addItem, postItem, clearFields} from '../actions';

class AddItemPage extends React.Component {

    onItemSubmit(itemState) {
        console.log('Submitting...', itemState);
        this.props.addItem(itemState);
        
        this.props.clearFields();
    }

    onInputChange(itemState) {
        console.log('Update state', itemState);
        this.props.addItem(itemState)
    }

    render() { 
    
        return (
            <div>
                <h1>Pasiskelbkite</h1>
                <AddItemForm 
                    onInputChange={this.onInputChange.bind(this)}
                    onItemSubmit={this.onItemSubmit.bind(this)} 
                    {...this.props} 
                />
            </div>
        )
    }    
}

export const mapStateToProps = (state) => {
    return {
        initialState: state.newItem
    }
}

export const mapDispatchToProps = (dispatch) => {
    return {
        addItem: (item) => dispatch(addItem(item)),
        clearFields: () => dispatch(clearFields()),
        postItem: (item) => dispatch(postItem(item))
    }
}

export default connect(mapStateToProps, mapDispatchToProps)(AddItemPage);