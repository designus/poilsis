import {RECEIVE_CITIES, SELECT_CITY, SET_LOADED_ITEMS_FLAG} from '../actions/cities';
import {normalizeData} from './helpers';

const cities = (state = null, action) => {
    switch(action.type) {
        case RECEIVE_CITIES: 
            const {dataMap, aliases} = normalizeData(action.payload);
            return {...state, dataMap, aliases};
            break;
        case SELECT_CITY: 
            return {...state, selectedId: action.cityId}
            break;
        case SET_LOADED_ITEMS_FLAG:
            return {
                ...state,
                 dataMap: {
                    ...state.dataMap, 
                    [action.cityId]: {
                        ...state.dataMap[action.cityId],
                        isItemsLoaded: true
                    }
                }
            }
            break;
        default:
            return state;    
    }
}

export default cities;