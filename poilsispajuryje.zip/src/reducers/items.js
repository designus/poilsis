import {SELECT_ITEM, RECEIVE_ITEMS, RECEIVE_ITEM } from '../actions/items';
import {normalizeData} from '../reducers/helpers';

const items = (state = {dataMap: {}, aliases: []}, action) => {
    switch(action.type) {
        case SELECT_ITEM: 
            return {...state, selectedId: action.itemId}
            break;
        case RECEIVE_ITEMS: 
            const {dataMap, aliases} = normalizeData(action.payload);
            return {
                ...state,
                dataMap: {
                    ...state.dataMap,
                    ...dataMap
                }, 
                aliases: [...state.aliases, ...aliases]
            };
            break;
        case RECEIVE_ITEM:
            const itemState = state.dataMap[action.item.id] || {};
            return {
                ...state,
                dataMap: {
                    ...state.dataMap,
                    [action.item.id]: {
                        ...itemState,
                        ...action.item,
                        fullInfo: true
                    }
                }
            }
        default:
            return state;
    }
}

export default items;