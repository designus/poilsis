import {ADD_ITEM, CLEAR_FIELDS} from '../actions';

export const initialNewItemState = { 
  title: '',
  city: '',
  types: [],
  address: '',
  description: '',
};

export const newItem = (state = initialNewItemState, action) => {
  switch(action.type) {
    case ADD_ITEM:
      return action.payload;
      break;
    case CLEAR_FIELDS:
      return {...initialNewItemState, types: []};
    default:
      return state;
  }
}